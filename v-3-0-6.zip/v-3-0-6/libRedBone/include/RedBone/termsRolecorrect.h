//
//角色统计模型
#import <Foundation/Foundation.h>
#import "subsetvaluedOpenMacrossymptom.h"
@interface KKRole : NSObject
/** 区服id */
@property(nonatomic, copy) NSString *serverid;
/** 区服名称 */
@property(nonatomic, copy) NSString *servername;
/** 角色ID */
@property(nonatomic, copy) NSString *roleid;
/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;
/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
-(void)setDequeueDamperclimatecryticpointsreplicadomain:(int)TaPAFaccentzonesscrollsloadingdequeue; 
-(void)setConduitteachfaultsescape:(NSString *)bladeguidemodelvowel_throughconduit; 
-(void)setColumnPacking_stereostanzaassets:(int)gainsstopsaisleparsecscolumn; 
-(void)setUpdatedRunningworkoutoAuth:(NSString *)Reentersharesheapsupdated; 
-(void)setGamutLsnA_formatslumensdummy:(NSString *)Dailyfiberfreightrebuildgamut; 
-(void)setVehicleAppend_severalcleared_seldom:(NSString *)Spindlereplicaenquiry_impliedglitchmistakevehicle; 
-(void)setSupposeDesirepassingmembers_scrollsbraking:(NSString *)serieslocallyfadeoutlockedofflinesuppose; 
-(void)setCountsnominal_displayambient:(NSString *)Colorstrellisbeeperstatusspawnedoverrunbegincounts; 
@end
